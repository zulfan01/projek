# Sistem Informasi Poliklinik

<h2>Screenshot</h2>
<p>Light Theme</p>
<p align="center">
  <img src="screenshot/lighttheme.png" width="500"/>
</p>
<p>Dark Theme</p>
<p align="center">
  <img src="screenshot/darktheme.png" width="500"/>
</p>
<p>Login Page 1</p>
<p align="center">
  <img src="screenshot/login.png" width="500"/>
</p>
<p>Login Page 2</p>
<p align="center">
  <img src="screenshot/login2.png" width="500"/>
</p>